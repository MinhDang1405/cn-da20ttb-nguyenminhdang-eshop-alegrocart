<?php
// Heading
$_['heading_title']       = 'Header';
$_['heading_description'] = 'Administration Header';

// Text
$_['text_heading']        = 'Administration';
$_['text_user']           = 'You are logged in as <b>%s</b>';
?>
