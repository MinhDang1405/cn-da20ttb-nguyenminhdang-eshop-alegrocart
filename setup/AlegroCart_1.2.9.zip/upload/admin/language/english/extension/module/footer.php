<?php
// Heading
$_['heading_title']      	= 'Footer';
$_['heading_description'] 	= 'Administration Footer';
$_['text_support']        	= 'Support AlegroCart and AlegroCart will Support you.<br>';
$_['text_powered_by'] 		= '<a href="http://www.alegrocart.com/">&copy;%s AlegroCart Powered</a><br>';
$_['text_developer']		= 'Developed by: %s';
?>