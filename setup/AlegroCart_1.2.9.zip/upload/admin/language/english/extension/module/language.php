<?php
// Heading 
$_['heading_title']  = 'Language';

// Text
$_['text_language']  = 'Select Language';

// Entry
$_['entry_language'] = 'Choose language:';
?>