<?php
// Heading
$_['heading_title']       = 'Login';
$_['heading_description'] = 'Please login using your username and password.';

// Text
$_['text_maintenance']		= 'Your store is in Maintenance mode!';

// Entry
$_['entry_username']      = 'Username';
$_['entry_password']      = 'Password';

// Button
$_['button_login']        = 'Login';

// Error
$_['error_login']         = 'No match for Username and/or Password.';
?>
