<?php
// Heading
$_['heading_title']       = 'Server Info';
$_['heading_description'] = 'This page shows some general information about your installation.';

// Text
$_['text_php']            = 'PHP Version:';
$_['text_db']             = 'DB Version:';
$_['text_db_server']      = 'Database Server:';
$_['text_db_name']        = 'Database Name:';
?>