<?php
// Heading
$_['heading_title']       = 'Catalog Navigation';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit navigation module details here.';

// Text
$_['text_message']        = 'Success: You have updated navigation module!';

// Entry
$_['entry_status']        = 'Status:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module navigation';
?>
