<?php
// Heading
$_['heading_title']       = 'Log Report';
$_['heading_description'] = 'You can view Log Files here.';

//Text
$_['text_select_file']		 = 'Select a File';
$_['text_select_dir']		 = 'Select a Directory';
$_['text_dycrypt_exp']		 = 'Only required on encrypted files';
//Entry
$_['entry_file']         = 'File Selection:';
$_['entry_dir']			 = 'Directory Selection:';
$_['entry_decrytion']	 = 'Decryption Required:';
//button
$_['button_submit']		 = 'Submit';
?>