<?php
// Heading
$_['heading_title']       = 'Home Page';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit HomePage module Status here with link to Homepage Entry.';

// Text
$_['text_message']        = 'Success: You have updated HomePage module!';
$_['text_save']           = ' * Save Status before proceeding to Entry Page!';
$_['text_homepage']       = 'Enter Home Page Data';
//Tabs
$_['tab_module']		  = 'HomePage Module';
$_['tab_homepage']        = 'Homepage Data Entry';
// Entry
$_['entry_status']        = 'Status:';

//Button
$_['button_home']         = 'HomePage Entry>>';
// Error
$_['error_permission']    = 'Warning: You do not have permission to modify homepage module';
?>
