<?php
// Heading
$_['heading_title']       = 'Catalog Search';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit your search module here.';

// Text
$_['text_message']        = 'Success: You have updated search module!';

// Entry
$_['entry_status']        = 'Status:';
$_['entry_ratings']       = 'Display Rating:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module search';

// Explanation
$_['explanation_entry_ratings']		= '';
?>
