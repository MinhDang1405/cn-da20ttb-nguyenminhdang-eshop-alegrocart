<?php
// Heading
$_['heading_title']       = 'Developer Information';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit developer information module details here.';

// Text
$_['text_message']        = 'Success: You have updated developer information module!';

// Entry
$_['entry_status']        = 'Status:';
$_['entry_developer']     = 'Developer:';
$_['entry_link']          = 'Website link:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify developer module';
?>
