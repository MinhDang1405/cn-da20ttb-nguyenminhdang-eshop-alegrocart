<?php 
// Heading
$_['heading_title']       = 'Calculate Subtotal';
$_['heading_calculate']   = 'Calculate:';
$_['heading_description'] = 'You can edit calculate subtotal settings here.';

// Text
$_['text_message']        = 'Success: You have updated calculate subtotal!';

// Entry
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Sort Order:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify calculate subtotal';
?>
