<?php
// Heading
$_['heading_title']       = 'Calculate Tax';
$_['heading_calculate']   = 'Calculate:';
$_['heading_description'] = 'You can edit calculate tax settings here.';

// Text
$_['text_message']        = 'Success: You have updated calculate tax!';

// Entry
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Sort Order:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify calculate tax';
?>
