<?php
// Entry
$_['entry_featured']       = 'Featured Product:';
$_['entry_specials']       = 'Special Offer:';
$_['entry_related']	       = 'Related Products:';

//Tab
$_['tab_home']             = 'Featured Specials<br>Related Products';
?>