<?php
// Heading
$_['heading_title']       = 'Cash On Delivery';
$_['heading_payment']     = 'Payment:';
$_['heading_description'] = 'You can edit cash on delivery payment module here.';

// Text
$_['text_message']        = 'Success: You have updated cash on delivery payment module!';

// Entry
$_['entry_status']        = 'Status:';
$_['entry_geo_zone']      = 'Geo Zone:';
$_['entry_sort_order']    = 'Sort Order:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify payment cash on delivery';
?>
