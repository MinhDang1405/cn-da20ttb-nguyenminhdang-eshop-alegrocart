<?php
// Heading
$_['heading_title']       = 'Maintenance Mode';
$_['heading_description'] = 'You can Set Maintenance Mode here.';

// Text
$_['text_message']        = 'Success: You have updated Maintenance!';

// Entry
$_['entry_status']        = 'Maintenance Status:';

// Explanation
$_['explanation_entry_status']  = 'When enabling maintenance mode customers will see maintenance page but shop admin has access if he logs in into the admin.';
?>