<?php
// Heading
$_['heading_title']       = 'People Online Report';
$_['heading_description'] = 'You can view your reports here.';

// Text
$_['text_guest']          = 'Guest';
$_['text_admin']          = '%s (Admin)';

// Column
$_['column_name']         = 'Customer';
$_['column_time']         = 'Last Click';
$_['column_ip']           = 'IP Address';
$_['column_url']          = 'Last URL';
$_['column_total']        = 'No. Cart Items';
?>