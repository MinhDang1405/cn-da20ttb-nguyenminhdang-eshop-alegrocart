<?php
// Heading
$_['heading_title']       = 'Products Viewed Report';
$_['heading_description'] = 'You can view your reports here.';

// Column
$_['column_name']         = 'Product Name';
$_['column_viewed']       = 'Viewed';
$_['column_percent']      = 'Percent';
?>