<?php
// Heading
$_['heading_title']       = 'Image Display';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You set Image Display module Status here with Link to Image Display entry.';

// Text
$_['text_message']        = 'Success: You have updated ImageDisplay module!';
$_['text_save']           = ' * Save Status before proceeding to Entry Page!';
$_['text_imagedisplay']   = 'Enter Image Display Data';
//Tabs
$_['tab_module']		  = 'Image Display ';
$_['tab_imagedisplay']    = 'Image Display Entry';
// Entry
$_['entry_status']        = 'Status:';

//Button
$_['button_home']         = 'ImageDisplay Entry>>';
// Error
$_['error_permission']    = 'Warning: You do not have permission to modify image display module';
?>
