<?php
// Heading
$_['heading_title']       = 'Page Not Found!';
$_['heading_description'] = 'The page you request could not be found!';
?>