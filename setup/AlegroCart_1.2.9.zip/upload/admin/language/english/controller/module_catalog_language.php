<?php
// Heading
$_['heading_title']       = 'Catalog Language';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit your language module here.';

// Text
$_['text_message']        = 'Success: You have updated language module!';

// Entry
$_['entry_status']        = 'Status:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module language';
?>
