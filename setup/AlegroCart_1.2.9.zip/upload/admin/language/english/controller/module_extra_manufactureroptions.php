<?php
// Heading
$_['heading_title']       = 'Manufacturer Options';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit manufacturer options module details here.';

// Text
$_['text_message']        = 'Success: You have updated manufacturer options module!';

// Entry
$_['entry_status']        = 'Status:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify manufacturers module';
?>
