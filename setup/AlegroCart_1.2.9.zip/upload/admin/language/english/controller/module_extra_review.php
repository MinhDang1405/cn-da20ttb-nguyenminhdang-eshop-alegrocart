<?php
// Heading
$_['heading_title']		= 'Review';
$_['heading_module']		= 'Module:';
$_['heading_description']	= 'You can edit review module details here.';

// Text
$_['text_message']		= 'Success: You have updated review module!';

// Entry
$_['entry_status']		= 'Status:';
$_['entry_image_display']	= 'Image Display:';

// Error
$_['error_permission']		= 'Warning: You do not have permission to modify module review';
?>
