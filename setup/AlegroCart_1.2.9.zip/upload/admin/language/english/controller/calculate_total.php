<?php
// Heading
$_['heading_title']       = 'Calculate Total';
$_['heading_calculate']   = 'Calculate:';
$_['heading_description'] = 'You can edit calculate total settings here.';

// Text
$_['text_message']        = 'Success: You have updated calculate total!';

// Entry
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Sort Order:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify calculate total';
?>
