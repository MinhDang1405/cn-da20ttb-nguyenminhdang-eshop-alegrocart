<?php
// Heading
$_['heading_title']       = 'Catalog Footer';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit footer module details here.';

// Text
$_['text_message']        = 'Success: You have updated footer module!';

// Entry
$_['entry_status']        = 'Status:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module footer';
?>
