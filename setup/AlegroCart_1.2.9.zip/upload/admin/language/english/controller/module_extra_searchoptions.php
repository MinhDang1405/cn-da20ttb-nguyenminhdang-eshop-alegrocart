<?php
// Heading
$_['heading_title']       = 'Search Options';
$_['heading_module']      = 'Module:';
$_['heading_description'] = 'You can edit search options module details here.';

// Text
$_['text_message']        = 'Success: You have updated search options module!';

// Entry
$_['entry_status']        = 'Status:';
$_['entry_columns']       = 'Default Number of Display Columns:';
$_['entry_display_lock']  = 'Lock Column Display to Default:';
// Error
$_['error_permission']    = 'Warning: You do not have permission to modify search module';
?>
