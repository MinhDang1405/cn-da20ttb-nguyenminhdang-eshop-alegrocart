<?php
// Heading
$_['heading_title']       = 'Products Purchased Report';
$_['heading_description'] = 'You can view your reports here.';

// Column
$_['column_name']         = 'Product Name';
$_['column_model_number'] = 'Model Number';
$_['column_quantity']     = 'Quantity';
$_['column_total']        = 'Total';
?>